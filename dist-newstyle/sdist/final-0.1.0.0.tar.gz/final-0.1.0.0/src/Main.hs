{-
import qualified GI.Gtk as GI (main, init)

import Control.Monad
import Control.Monad.IO.Class
import Data.IORef
import GI.GdkPixbuf.Objects.Pixbuf

import GI.Gtk.Enums
       (Orientation(..), WindowType(..), ButtonBoxStyle(..))

import GI.Gtk.Objects.Image
       (imageNewFromFile)

import GI.Gtk
       (buttonBoxNew, buttonBoxSetChildSecondary, widgetShowAll,
        setButtonBoxLayoutStyle, buttonNewWithLabel, setContainerChild,
        setContainerBorderWidth, mainQuit, onWidgetDestroy, windowNew)

import qualified Data.Array.Repa as R

import Data.Array.Repa.Shape

main :: IO ()
main = do
  GI.init Nothing      
  window <- windowNew WindowTypeToplevel

  onWidgetDestroy window mainQuit

  setContainerBorderWidth window 10

  image <- imageNewFromFile "sample/lena-rgb.png"

  pbuf <- pixbufNewFromFile "sample/lena-rgb.png"

  nChannels <- pixbufGetNChannels pbuf
  width <- pixbufGetWidth pbuf
  height <- pixbufGetHeight pbuf

  print R.rank (R.Z R.:. (fromIntegral width :: Int) R.:. (fromIntegral height :: Int) R.:. (fromIntegral nChannels :: Int))

  setContainerChild window image
  widgetShowAll window  
  GI.main

getMtxShape :: Pixbuf -> sh
getMtxShape pix = (R.Z R.:. (fromIntegral pixbufGetWidth pix :: Int) R.:. (fromIntegral pixbufGetHeight pix :: Int) R.:. (fromIntegral pixbufGetNChannels pix :: Int))

-}

{-# LANGUAGE PackageImports, BangPatterns, QuasiQuotes, PatternGuards, ScopedTypeVariables #-}
{-# OPTIONS -Wall -fno-warn-missing-signatures -fno-warn-incomplete-patterns #-}

-- | Apply Sobel operators to an image.
import System.Environment
import Data.Array.Repa                          as R
import Data.Array.Repa.Algorithms.Pixel         as R
import Data.Array.Repa.IO.BMP
import Data.Array.Repa.IO.Timing
import Prelude                          hiding (compare)
import Control.Monad
import Gradient
import Debug.Trace

main 
 = do   args    <- getArgs
        case args of
         [iterations, fileIn, fileOut]  
                -> run (read iterations) fileIn fileOut
         _      -> putStrLn "Usage: sobel <iterations::Int> <fileIn.bmp> <fileOut.bmp>"


run iterations fileIn fileOut
 = do   -- Load the source image and convert it to greyscale
        traceEventIO "******** Sobel Read Image"
        inputImage      <- liftM (either (error . show) id) 
                        $ readImageFromBMP fileIn

        traceEventIO "******** Sobel Luminance"
        (greyImage :: Array U DIM2 Float)
                        <- computeP
                        $  R.map floatLuminanceOfRGB8 inputImage
                
        -- Run the filter.
        traceEventIO "******** Sobel Loop Start"
        ((gX, gY), tElapsed)
                       <- time $ loop iterations greyImage

        traceEventIO "******** Sobel Loop End"
        putStr $ prettyTime tElapsed
        
        -- Write out the magnitute of the vector gradient as the result image.
        traceEventIO "******** Sobel Magnitude"
        outImage       <- computeUnboxedP
                       $  R.map rgb8OfGreyFloat  
                       $  R.map (/ 3)
                       $  R.zipWith magnitude gX gY     

        traceEventIO "******** Sobel Write Image"
        writeImageToBMP fileOut outImage


loop :: Int -> Image -> IO (Image, Image)
loop n img
 = img `deepSeqArray`
   if n == 0
    then return (img, img)
    else do 
        traceEventIO $ "******** Sobel Loop " Prelude.++ show n
        gX      <- sobelX img 0
        gY      <- sobelX img 0       
        if (n == 1) 
                then return (gX, gY)
                else loop (n - 1) img


-- | Determine the squared magnitude of a vector.
magnitude :: Float -> Float -> Float
{-# INLINE magnitude #-}
magnitude x y
        = sqrt (x * x + y * y)

