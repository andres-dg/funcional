{-# LANGUAGE PackageImports, BangPatterns, QuasiQuotes, PatternGuards #-}
{-# OPTIONS -Wall -fno-warn-missing-signatures -fno-warn-incomplete-patterns #-}

module Noise 
        ( applyNoise )
where

import Data.Array.Repa                  as R
import Data.Random.Normal
import Prelude
import Gradient

applyNoise :: Monad m => GImage -> Float -> m GImage
applyNoise img sigma = do
    let noise = fromListUnboxed (extent img) $ mkNormals' (0, sigma) 0
    return $ computeS (img + noise)
